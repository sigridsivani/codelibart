x = 5
y = 10
if x > y: 
    print("Greater than fiiiiive!")
else:
    print("less than five")